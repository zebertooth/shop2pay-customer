# Shop2Pay-Customer

Meteor, React, Authentication, Bootstrap and Router boilerplate.

# Demo

[http://shop2pay-customer.herokuapp.com/](http://shop2pay-customer.herokuapp.com/)
